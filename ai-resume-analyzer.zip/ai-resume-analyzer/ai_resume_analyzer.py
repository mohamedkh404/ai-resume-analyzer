import tkinter as tk
from tkinter import filedialog, messagebox
import pdfplumber
import docx
import spacy
import pandas as pd
import matplotlib.pyplot as plt
from collections import Counter
nlp = spacy.load("en_core_web_sm")
class ResumeAnalyzerApp:
    def __init__(self, root):
        self.root = root
        self.root.title("AI Resume Analyzer")
        self.root.geometry("600x400")
        tk.Label(root, text="AI Resume Analyzer", font=("Helvetica", 20, "bold")).pack(pady=20)
        tk.Button(root, text="Upload Resume (PDF/DOCX)", command=self.upload_file, width=30, bg="#4CAF50", fg="white").pack(pady=10)
        tk.Button(root, text="Analyze Resume", command=self.analyze_resume, width=30, bg="#2196F3", fg="white").pack(pady=10)
        self.resume_text = ""
        self.skills_counter = Counter()
    def upload_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("PDF files", "*.pdf"), ("Word files", "*.docx")])
        if not file_path:
            return
        if file_path.endswith(".pdf"):
            self.resume_text = self.read_pdf(file_path)
        elif file_path.endswith(".docx"):
            self.resume_text = self.read_docx(file_path)
        else:
            messagebox.showerror("Error", "Unsupported file type!")
            return
        messagebox.showinfo("Success", "Resume uploaded successfully!")
    def read_pdf(self, path):
        text = ""
        with pdfplumber.open(path) as pdf:
            for page in pdf.pages:
                text += page.extract_text() + "\n"
        return text
    def read_docx(self, path):
        doc = docx.Document(path)
        text = "\n".join([para.text for para in doc.paragraphs])
        return text
    def analyze_resume(self):
        if not self.resume_text:
            messagebox.showwarning("Warning", "Please upload a resume first!")
            return
        doc = nlp(self.resume_text)
        skills = [ent.text for ent in doc.ents if ent.label_ in ["ORG", "GPE", "PERSON", "LANGUAGE", "SKILL"]]
        self.skills_counter = Counter(skills)
        if not skills:
            messagebox.showinfo("Result", "No skills detected.")
        else:
            df = pd.DataFrame(self.skills_counter.items(), columns=["Skill", "Count"])
            df.to_csv("resume_skills_report.csv", index=False)
            messagebox.showinfo("Result", f"Skills extracted! Report saved as resume_skills_report.csv")
            self.plot_skills(df)
    def plot_skills(self, df):
        plt.figure(figsize=(10,5))
        plt.bar(df["Skill"], df["Count"], color="#4CAF50")
        plt.xticks(rotation=45, ha="right")
        plt.title("Skills Frequency")
        plt.tight_layout()
        plt.show()
if __name__ == "__main__":
    root = tk.Tk()
    app = ResumeAnalyzerApp(root)
    root.mainloop()
